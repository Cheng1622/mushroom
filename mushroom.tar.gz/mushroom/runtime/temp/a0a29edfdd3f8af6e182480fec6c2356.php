<?php if (!defined('THINK_PATH')) exit(); /*a:6:{s:68:"E:\www\mushroom\public/../application/index\view\mushroom\index.html";i:1637725388;s:65:"E:\www\mushroom\public/../application/index\view\public\base.html";i:1501913354;s:65:"E:\www\mushroom\public/../application/index\view\public\meta.html";i:1637582504;s:67:"E:\www\mushroom\public/../application/index\view\public\header.html";i:1637575608;s:65:"E:\www\mushroom\public/../application/index\view\public\menu.html";i:1637577445;s:67:"E:\www\mushroom\public/../application/index\view\public\footer.html";i:1502291361;}*/ ?>
<!--_meta 作为公共模版分离出去-->
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="Bookmark" href="favicon.ico" >
    <link rel="Shortcut Icon" href="favicon.ico" />
    <!--[if lt IE 9]>
    <script type="text/javascript" src="__STATIC__/lib/html5.js"></script>
    <script type="text/javascript" src="__STATIC__/lib/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" type="text/css" href="__STATIC__/static/h-ui/css/H-ui.min.css" />
    <link rel="stylesheet" type="text/css" href="__STATIC__/static/h-ui.admin/css/H-ui.admin.css" />
    <link rel="stylesheet" type="text/css" href="__STATIC__/lib/Hui-iconfont/1.0.8/iconfont.css" />
    <link rel="stylesheet" type="text/css" href="__STATIC__/static/h-ui.admin/skin/default/skin.css" id="skin" />
    <link rel="stylesheet" type="text/css" href="__STATIC__/static/h-ui.admin/css/style.css" />
    <!--导入boostrap-->
    <link rel="stylesheet" href="__STATIC__/lib/bootstrap/css/bootstrap.min.css" />
    <!--[if IE 6]>
    <script type="text/javascript" src="http://lib.h-ui.net/DD_belatedPNG_0.0.8a-min.js" ></script>
    <script>DD_belatedPNG.fix('*');</script>
    <![endif]-->
    <!--/meta 作为公共模版分离出去-->


<title><?php echo (isset($title) && ($title !== '')?$title:'标题'); ?></title>
<meta name="keywords" content="<?php echo (isset($keywords) && ($keywords !== '')?$keywords:'关键字'); ?>">
<meta name="description" content="<?php echo (isset($desc) && ($desc !== '')?$desc:'描述'); ?>">
<!-- App favicon -->
<!-- <link rel="shortcut icon" href="__STATIC__/static/h-ui//images/favicon.ico"> -->

<!-- C3 charts css -->
<link href="__STATIC__/static/assets/css/c3.min.css" rel="sstylesheet" type="text/css" />

<!-- App css -->
<link href="__STATIC__/static/assets/css/icons.css" rel="stylesheet" type="text/css" />
<link href="__STATIC__/static/assets/css/metismenu.min.css" rel="stylesheet" type="text/css" />
<link href="__STATIC__/static/assets/css/style.css" rel="stylesheet" type="text/css" />

<script src="__STATIC__/static/assets/js/modernizr.min.js"></script>


</head>
<body>


<!--_header 作为公共模版分离出去-->
<header class="navbar-wrapper">
    <div class="navbar navbar-fixed-top">
        <div class="container-fluid cl">
            <a class="logo navbar-logo f-l mr-10 hidden-xs" href="<?php echo url('index/index'); ?>">mushroom</a>
            <a class="logo navbar-logo-m f-l mr-10 visible-xs" href="<?php echo url('index/index'); ?>">mushroom</a>
            <!--<span class="logo navbar-slogan f-l mr-10 hidden-xs">v3.0</span>-->
            <a aria-hidden="false" class="nav-toggle Hui-iconfont visible-xs" href="javascript:;">&#xe667;</a>
            <nav id="Hui-userbar" class="nav navbar-nav navbar-userbar hidden-xs">
                <ul class="cl">
                    <li>
                        <?php if(\think\Session::get('user_info.name') == 'admin'): ?>
                        超级管理员
                        <?php else: if(\think\Session::get('user_info.role') == '1'): ?>
                            超级管理员
                          <?php else: ?>
                            管理员
                         <?php endif; endif; ?>

                    </li>
                    <li class="dropDown dropDown_hover"> <a href="#" class="dropDown_A"><?php echo session('user_info.name'); ?> <i class="Hui-iconfont">&#xe6d5;</i></a>
                        <ul class="dropDown-menu menu radius box-shadow">

                            <li><a href="<?php echo url('user/logout'); ?>">退出</a></li>
                        </ul>
                    </li>
                    <li id="Hui-skin" class="dropDown right dropDown_hover"> <a href="javascript:;" class="dropDown_A" title="换肤"><i class="Hui-iconfont" style="font-size:18px">&#xe62a;</i></a>
                        <ul class="dropDown-menu menu radius box-shadow">
                            <li><a href="javascript:;" data-val="default" title="默认（黑色）">默认（黑色）</a></li>
                            <li><a href="javascript:;" data-val="blue" title="蓝色">蓝色</a></li>
                            <li><a href="javascript:;" data-val="green" title="绿色">绿色</a></li>
                            <li><a href="javascript:;" data-val="red" title="红色">红色</a></li>
                            <li><a href="javascript:;" data-val="yellow" title="黄色">黄色</a></li>
                            <li><a href="javascript:;" data-val="orange" title="橙色">橙色</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</header>
<!--/_header 作为公共模版分离出去-->




<!--_menu 作为公共模版分离出去-->
<aside class="Hui-aside" style="position: absolute;top:50px">

    <div class="menu_dropdown bk_2">
        <dl id="menu-admin">
            <dt><i class="Hui-iconfont">&#xe62d;</i> 蘑菇管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
            <dd>
                <ul>

                    <li><a href="<?php echo url('mushroom/index'); ?>" title="蘑菇分析">蘑菇分析</a></li>
                    <li><a href="<?php echo url('grade/gradeList'); ?>" title="蘑菇列表">蘑菇列表</a></li>
                </ul>
            </dd>
        </dl>

        <dl id="menu-admin">
            <dt><i class="Hui-iconfont">&#xe62d;</i> 管理员管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
            <dd>
                <ul>
                    <li><a href="<?php echo url('user/adminList'); ?>" title="管理员列表">管理员列表</a></li>
                </ul>
            </dd>
        </dl>

    </div>
</aside>
<div class="dislpayArrow hidden-xs"><a class="pngfix" href="javascript:void(0);" onClick="displaynavbar(this)"></a></div>
<!--/_menu 作为公共模版分离出去-->


<section class="Hui-article-box" style="position: absolute;">
    <nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页
        <span class="c-gray en">&gt;</span>
        蘑菇管理
        <span class="c-gray en">&gt;</span>
        蘑菇分析 <a class="btn btn-success radius r" style="line-height:1.6em;margin-top:3px"
            href="javascript:location.replace(location.href);" title="刷新"><i class="Hui-iconfont">&#xe68f;</i></a>
    </nav>
    <div class="Hui-article">
        <!--视频-->

        <!-- <div id="wrapper" style="margin-top: 50px;"> -->
            <div class="content-page" style="margin-top: 50px;">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <!-- end row -->


                        <div class="row" style="display:flex;">

                            <div class="video-wrapper col-md-12" style="margin-left:1%">
                                <video id="videojs-contrib-hls-player" poster=""
                                    class="video-js vjs-default-skin syau-2019 row col-md-9  col-xs-12 col-md-offset-0"
                                    controls>
                                    <source src="" type="application/x-mpegURL">
                                </video>
                            </div>

                            <!-- <div class="col-lg-3 col-md-6">
                                    <div class="video-wrapper col-md-12">
                                        <video id="videojs-contrib-hls-player" poster=""
                                            class="video-js vjs-default-skin syau-2019 row col-md-9  col-xs-12 col-md-offset-0" controls>
                                            <source src="" type="application/x-mpegURL">
                                        </video>
                                    </div>
                            </div> -->
                            <!-- <div class="col-lg-3 col-md-6">
                                <div class="card-box widget-box-two widget-two-custom">
                                    <i class="mdi mdi-account-multiple widget-two-icon"></i>
                                    <div class="wigdet-two-content">
                                        <p class="m-0 text-uppercase font-bold font-secondary text-overflow"
                                            title="Statistics">残缺程度</p>
                                        <h2 class="font-600"><span><i class="mdi mdi-arrow-up"></i></span> <span
                                                data-plugin="counterup">236521</span></h2>
                                        <p class="m-0">Jan - Apr 2017</p>
                                    </div>
                                </div>
                            </div> -->

                            <div class="col-lg-3 col-md-6">
                                <div class="card-box widget-box-two widget-two-custom">
                                    <i class="mdi mdi-crown widget-two-icon"></i>
                                    <div class="wigdet-two-content">
                                        <p class="m-0 text-uppercase font-bold font-secondary text-overflow"
                                            title="Statistics">褐变程度</p>
                                        <h2 class="font-600"><span><i class="mdi mdi-arrow-up"></i></span> <span
                                                data-plugin="counterup">563</span></h2>
                                        <p class="m-0">Jan - Apr 2017</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-6">
                                <div class="card-box widget-box-two widget-two-custom">
                                    <i class="mdi mdi-crown widget-two-icon"></i>
                                    <div class="wigdet-two-content">
                                        <p class="m-0 text-uppercase font-bold font-secondary text-overflow"
                                            title="Statistics">残缺程度</p>
                                        <h2 class="font-600"><span><i class="mdi mdi-arrow-up"></i></span> <span
                                                data-plugin="counterup">563</span></h2>
                                        <p class="m-0">Jan - Apr 2017</p>
                                    </div>
                                </div>
                            </div><!-- end col -->

                            <div class="col-lg-3 col-md-6">
                                <div class="card-box widget-box-two widget-two-custom">
                                    <i class="mdi mdi-auto-fix widget-two-icon"></i>
                                    <div class="wigdet-two-content">
                                        <p class="m-0 text-uppercase font-bold font-secondary text-overflow"
                                            title="Statistics">大小比值</p>
                                        <h2 class="font-600"><span><i class="mdi mdi-arrow-up"></i></span> <span
                                                data-plugin="counterup">2.07</span>%</h2>
                                        <p class="m-0">Jan - Apr 2017</p>
                                    </div>
                                </div>
                            </div><!-- end col -->

                        </div>
                        <!-- end row -->


                        <div class="row">
                            <div class="col-lg-4">
                                <div class="card-box">
                                    <h4 class="header-title m-t-0 m-b-30">等级划分</h4>

                                    <div class="text-center">
                                        <h5 class="font-normal text-muted">蘑菇等级</h5>
                                        <!-- <h3 class="m-b-30"><i
                                                class="mdi mdi-arrow-up-bold-hexagon-outline text-success"></i> 25643
                                            <small></small>
                                        </h3> -->
                                    </div>

                                    <div class="chart-container">
                                        <div class="" style="height:280px" id="platform_type_dates_donut"></div>
                                    </div>
                                </div>
                            </div>



                            <!--  -->
                            <div class="col-lg-4">
                                <div class="card-box">
                                    <h4 class="header-title m-t-0 m-b-30">大小划分</h4>

                                    <div class="text-center">
                                        <h5 class="font-normal text-muted">蘑菇大小</h5>
                                        <!-- <h3 class="m-b-30"><i
                                                class="mdi mdi-arrow-down-bold-hexagon-outline text-danger"></i> 5623
                                            <small>USD</small>
                                        </h3> -->
                                    </div>

                                    <div class="chart-container">
                                        <div class="" style="height:280px" id="user_type_bar"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="card-box">
                                    <h4 class="header-title m-t-0 m-b-30">褐变划分</h4>

                                    <div class="text-center">
                                        <h5 class="font-normal text-muted">蘑菇褐变</h5>
                                        <!-- <h3 class="m-b-30"><i
                                                class="mdi mdi-arrow-up-bold-hexagon-outline text-success"></i> 12548
                                            <small>USD</small>
                                        </h3> -->
                                    </div>

                                    <div class="chart-container">
                                        <div class="chart has-fixed-height" style="height:280px" id="page_views_today">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->




                        
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card-box">
                                    <h4 class="m-t-0 header-title"><b>Recent Candidates</b></h4>
                                    <p class="text-muted font-14 m-b-20">
                                        Your awesome text goes here.
                                    </p>

                                    <div class="table-responsive">
                                        <table class="table table-hover m-0 table-actions-bar">

                                            <thead>
                                                <tr>
                                                    <th>
                                                        <div class="btn-group dropdown">
                                                            <button type="button"
                                                                class="btn btn-secondary btn-xs dropdown-toggle waves-effect waves-light"
                                                                data-toggle="dropdown" aria-expanded="false"><i
                                                                    class="caret"></i></button>
                                                            <div class="dropdown-menu">
                                                                <a class="dropdown-item" href="#">Dropdown link</a>
                                                                <a class="dropdown-item" href="#">Dropdown link</a>
                                                            </div>
                                                        </div>
                                                    </th>
                                                    <th>Name</th>
                                                    <th>Location</th>
                                                    <th>Job Timing</th>
                                                    <th>Salary</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <img src="__STATIC__/static/assets/images/users/avatar-2.jpg"
                                                            alt="contact-img" title="contact-img"
                                                            class="rounded-circle thumb-sm" />
                                                    </td>

                                                    <td>
                                                        <h5 class="m-b-0 m-t-0 font-600">Tomaslau</h5>
                                                        <p class="m-b-0"><small>Web Designer</small></p>
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-map-marker text-primary"></i> New York
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-clock text-success"></i> Full Time
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-currency-usd text-warning"></i> 3265
                                                    </td>

                                                    <td>
                                                        <a href="#" class="table-action-btn"><i
                                                                class="mdi mdi-pencil"></i></a>
                                                        <a href="#" class="table-action-btn"><i
                                                                class="mdi mdi-close"></i></a>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <img src="__STATIC__/static/assets/images/users/avatar-3.jpg"
                                                            alt="contact-img" title="contact-img"
                                                            class="rounded-circle thumb-sm" />
                                                    </td>

                                                    <td>
                                                        <h5 class="m-b-0 m-t-0 font-600">Erwin E. Brown</h5>
                                                        <p class="m-b-0"><small>Programmer</small></p>
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-map-marker text-primary"></i> California
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-clock text-success"></i> Part Time
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-currency-usd text-warning"></i> 1365
                                                    </td>

                                                    <td>
                                                        <a href="#" class="table-action-btn"><i
                                                                class="mdi mdi-pencil"></i></a>
                                                        <a href="#" class="table-action-btn"><i
                                                                class="mdi mdi-close"></i></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <img src="__STATIC__/static/assets/images/users/avatar-4.jpg"
                                                            alt="contact-img" title="contact-img"
                                                            class="rounded-circle thumb-sm" />
                                                    </td>

                                                    <td>
                                                        <h5 class="m-b-0 m-t-0 font-600">Margeret V. Ligon</h5>
                                                        <p class="m-b-0"><small>Web Designer</small></p>
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-map-marker text-primary"></i> New York
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-clock text-success"></i> Full Time
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-currency-usd text-warning"></i> 115248
                                                    </td>

                                                    <td>
                                                        <a href="#" class="table-action-btn"><i
                                                                class="mdi mdi-pencil"></i></a>
                                                        <a href="#" class="table-action-btn"><i
                                                                class="mdi mdi-close"></i></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <img src="__STATIC__/static/assets/images/users/avatar-5.jpg"
                                                            alt="contact-img" title="contact-img"
                                                            class="rounded-circle thumb-sm" />
                                                    </td>

                                                    <td>
                                                        <h5 class="m-b-0 m-t-0 font-600">Jose D. Delacruz</h5>
                                                        <p class="m-b-0"><small>Web Developer</small></p>
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-map-marker text-primary"></i> New York
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-clock text-success"></i> Part Time
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-currency-usd text-warning"></i> 2451
                                                    </td>

                                                    <td>
                                                        <a href="#" class="table-action-btn"><i
                                                                class="mdi mdi-pencil"></i></a>
                                                        <a href="#" class="table-action-btn"><i
                                                                class="mdi mdi-close"></i></a>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <td>
                                                        <img src="__STATIC__/static/assets/images/users/avatar-8.jpg"
                                                            alt="contact-img" title="contact-img"
                                                            class="rounded-circle thumb-sm" />
                                                    </td>

                                                    <td>
                                                        <h5 class="m-b-0 m-t-0 font-600">Luke J. Sain</h5>
                                                        <p class="m-b-0"><small>Web Designer</small></p>
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-map-marker text-primary"></i> Australia
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-clock text-success"></i> Part Time
                                                    </td>

                                                    <td>
                                                        <i class="mdi mdi-currency-usd text-warning"></i> 3265
                                                    </td>

                                                    <td>
                                                        <a href="#" class="table-action-btn"><i
                                                                class="mdi mdi-pencil"></i></a>
                                                        <a href="#" class="table-action-btn"><i
                                                                class="mdi mdi-close"></i></a>
                                                    </td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                            <!-- end col -->

                            <div class="col-lg-3">
                                <div class="card-box">
                                    <h4 class="header-title m-t-0 m-b-30">Total Unique Visitors</h4>

                                    <div class="widget-chart text-center">

                                        <div id="donut-chart" style="height: 270px;"></div>

                                        <div class="row text-center m-t-30">
                                            <div class="col-6">
                                                <h3 data-plugin="counterup">1,507</h3>
                                                <p class="text-muted m-b-5">Visitors Male</p>
                                            </div>
                                            <div class="col-6">
                                                <h3 data-plugin="counterup">854</h3>
                                                <p class="text-muted m-b-5">Visitors Female</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>


                            <div class="col-lg-3">
                                <div class="card-box">
                                    <h4 class="header-title m-t-0 m-b-30">Number of Transactions</h4>

                                    <div class="widget-chart text-center">

                                        <div id="pie-chart" style="height: 270px;"></div>

                                        <div class="row text-center m-t-30">
                                            <div class="col-6">
                                                <h3 data-plugin="counterup">2,854</h3>
                                                <p class="text-muted m-b-5">Payment Done</p>
                                            </div>
                                            <div class="col-6">
                                                <h3 data-plugin="counterup">22</h3>
                                                <p class="text-muted m-b-5">Payment Due</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                        <!--- end row -->

                    </div> <!-- container -->

                </div> <!-- content -->
            </div>
        </div>
</section>



<!--_footer 作为公共模版分离出去-->
<script type="text/javascript" src="__STATIC__/lib/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="__STATIC__/lib/layer/2.4/layer.js"></script>
<script type="text/javascript" src="__STATIC__/static/h-ui/js/H-ui.js"></script>
<script type="text/javascript" src="__STATIC__/static/h-ui.admin/js/H-ui.admin.page.js"></script>
<!--导入boostrap-->
<script type="text/javascript" src="__STATIC__/lib/bootstrap/js/bootstrap.min.js"></script>

<!--/_footer /作为公共模版分离出去-->


<!--请在下方写此页面业务相关的脚本-->
<script type="text/javascript" src="__STATIC__/lib/My97DatePicker/4.8/WdatePicker.js"></script>
<script type="text/javascript" src="__STATIC__/lib/datatables/1.10.0/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="__STATIC__/lib/laypage/1.2/laypage.js"></script>

<!-- jQuery  -->
<!-- <script src="__STATIC__/static/assets/js/tether.min.js"></script> -->
<script src="__STATIC__/static/assets/js/bootstrap.min.js"></script>
<script src="__STATIC__/static/assets/js/metisMenu.min.js"></script>
<script src="__STATIC__/static/assets/js/waves.js"></script>
<script src="__STATIC__/static/assets/js/jquery.slimscroll.js"></script>
<!-- x<script src="__STATIC__/static/assets/js/jquery.min.js"></script> -->

<!-- Counter js  -->
<script src="__STATIC__/static/assets/js/jquery.waypoints.min.js"></script>
<script src="__STATIC__/static/assets/js/jquery.counterup.min.js"></script>

<!--C3 Chart-->
<script type="text/javascript" src="__STATIC__/static/assets/js/d3.min.js"></script>
<script type="text/javascript" src="__STATIC__/static/assets/js/c3.min.js"></script>

<!--Echart Chart-->
<script src="__STATIC__/static/assets/js/echarts-all.js"></script>

<!-- Dashboard init -->
<script src="__STATIC__/static/assets/pages/jquery.dashboard.js"></script>

<!-- App js -->
<script src="__STATIC__/static/assets/js/jquery.core.js"></script>
<script src="__STATIC__/static/assets/js/jquery.app.js"></script>


<!-- <script src="http://zhibo.syau.edu.cn/jquery.min.js"></script>  -->
<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<!-- <script src="http://zhibo.syau.edu.cn/bootstrap.min.js"></script> -->
<link href="http://zhibo.syau.edu.cn/front/video-js.min.css" rel="stylesheet">
<script src="http://zhibo.syau.edu.cn/front/video.min.js"></script>
<script src="http://zhibo.syau.edu.cn/front/videojs-flash.js"></script>
<script src="http://zhibo.syau.edu.cn/front/videojs-contrib-hls.js"></script>

<!--<link href="__STATIC__/static/video/css/video-js.min.scss" rel="stylesheet">
<script src="__STATIC__/static/video/js/video.js"></script>
<script src="__STATIC__/static/video/js/tracks/videojs-flash.js"></script>
<script src="__STATIC__/static/video/js/tracks/videojs-contrib-hls.js"></script>
<script type="text/javascript">
    $(function () {
        $('source').attr("src", "http://cctvalih5ca.v.myalicdn.com/live/cctv1_2/index.m3u8");
        (function (window, videojs) {
            var player = window.player = videojs('videojs-contrib-hls-player');
            // var loadUrl = document.getElementById('load-url');
            // var url = document.getElementById('url');
            loadUrl.addEventListener('submit', function (event) {
                event.preventDefault();
                player.src({
                    src: url.value,
                    type: 'application/x-mpegURL'
                });
                return false;
            });
        }(window, window.videojs));
    });
</script> -->

</body>
</html>