<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:64:"E:\www\mushroom\public/../application/index\view\user\login.html";i:1637381541;}*/ ?>
﻿<!DOCTYPE HTML>
<html>

<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit|ie-comp|ie-stand">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport"
		content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
	<meta http-equiv="Cache-Control" content="no-siteapp" />
	<!--[if lt IE 9]>
<script type="text/javascript" src="__STATIC__/lib/html5.js"></script>
<script type="text/javascript" src="__STATIC__/lib/respond.min.js"></script>
<![endif]-->
	<link href="__STATIC__/static/h-ui/css/H-ui.min.css" rel="stylesheet" type="text/css" />
	<link href="__STATIC__/static/h-ui/css/H-ui.login.css" rel="stylesheet" type="text/css" />
	<link href="__STATIC__/static/h-ui.admin/css/style.css" rel="stylesheet" type="text/css" />
	<link href="__STATIC__/lib/Hui-iconfont/1.0.8/iconfont.css" rel="stylesheet" type="text/css" />
	<!--[if IE 6]>
<script type="text/javascript" src="http://lib.h-ui.net/DD_belatedPNG_0.0.8a-min.js" ></script>
<script>DD_belatedPNG.fix('*');</script><![endif]-->
	<title><?php echo (isset($title) && ($title !== '')?$title:'标题'); ?></title>
<!-- <meta name="keywords" content="<?php echo (isset($keywords) && ($keywords !== '')?$keywords:'关键字'); ?>"> -->
<!-- <meta name="description" content="<?php echo (isset($desc) && ($desc !== '')?$desc:'描述'); ?>"> -->
</head>

<body>
	<canvas class="cavs" width="780" height="721"></canvas>

	<!-- <input type="hidden" id="TenantId" name="TenantId" value="" /> -->
	<div class="loginWraper">
		<div id="loginform" class="loginBox">
			<div class="img"></div>
			<form class="form form-horizontal" action="index.html" method="post">
				<div class="row cl ">
					<input id="" name="name" type="text" placeholder="用户名" class="input-text size-L radius">
				</div>
				<div class="row cl">
					<input id="" name="password" type="password" placeholder="密码" class="input-text size-L radius">
				</div>
				<div class="row cl">
					<input name="captcha" class="input-text size-L radius" type="text" 
					placeholder="验证码" onblur="if(this.value==''){this.value=''}" onclick="if(this.value==''){this.value='';}"
						value="" style="width:50%;">
					<!-- <img src="<?php echo captcha_src(); ?>" id="captcha_img"> -->
					<a id="kanbuq" href="javascript:captcha_refresh();"><img style="float:right;width:45%;height: 41px;" src="<?php echo captcha_src(); ?>"
							id="captcha_img"></a>
				</div>
				<div class="row cl">
					<label for="online">
						<input type="checkbox" name="online" id="online" value="">
						使我保持登录状态</label>
				</div>
				<div class="row cl">
					<input id="login" type="button" class="btn btn-primary radius size-L input-text"
						value="&nbsp;登&nbsp;&nbsp;&nbsp;&nbsp;录&nbsp;">
					</div>
				</div>
			</form>
		</div>
	</div>
	<div class="footer"><?php echo (isset($copyRight) && ($copyRight !== '')?$copyRight:"版权提示"); ?></div>

	<script type="text/javascript" src="__STATIC__/lib/jquery/1.9.1/jquery.js"></script>
	<script type="text/javascript" src="__STATIC__/lib/jquery/1.9.1/jquery.min.js"></script>
	<script type="text/javascript" src="__STATIC__/lib/layer/2.4/layer.js"></script>
	<script type="text/javascript" src="__STATIC__/static/h-ui/js/H-ui.js"></script>
	<!--ajax提交-->
	<script>
		$(function () {
			$('#login').on('click', function () {
				$.ajax({
					type: 'POST',
					url: "<?php echo url('checkLogin'); ?>",
					data: $('form').serialize(),
					dataType: 'json',
					success: function (data) {
						if (data.status == 1) {
							layer.msg(data.message,{shift:6});
							setTimeout(jump,3000);
						} else {
							layer.msg(data.message,{shift:6});
						}
					}
				});
			})
		})
		function jump(){
			window.location.href = "<?php echo url('index/index'); ?>"
		}
	</script>

	<!--自动刷新验证码-->
	<script>
		function captcha_refresh() {
			var str = Date.parse(new Date()) / 1000;
			$('#captcha_img').attr("src", "/captcha?id=" + str);
		}
	</script>

	
<script> 
	$(function() {
		var canvas = document.querySelector('canvas'),
			ctx = canvas.getContext('2d');
		canvas.width = $(window).width();
		canvas.height = $(window).height();
		ctx.lineWidth = .3;
		ctx.strokeStyle = (new Color(150)).style;
		var mousePosition = {
			x: 30 * canvas.width / 100,
			y: 30 * canvas.height / 100
		};
		var dots = {
			nb: 250,
			distance: 100,
			d_radius: 150,
			array: []
		};

		function colorValue(min) {
			return Math.floor(Math.random() * 255 + min);
		}

		function createColorStyle(r, g, b) {
			return 'rgba(' + r + ',' + g + ',' + b + ', 0.8)';
		}

		function mixComponents(comp1, weight1, comp2, weight2) {
			return (comp1 * weight1 + comp2 * weight2) / (weight1 + weight2);
		}

		function averageColorStyles(dot1, dot2) {
			var color1 = dot1.color,
				color2 = dot2.color;
			var r = mixComponents(color1.r, dot1.radius, color2.r, dot2.radius),
				g = mixComponents(color1.g, dot1.radius, color2.g, dot2.radius),
				b = mixComponents(color1.b, dot1.radius, color2.b, dot2.radius);
			return createColorStyle(Math.floor(r), Math.floor(g), Math.floor(b));
		}

		function Color(min) {
			min = min || 0;
			this.r = colorValue(min);
			this.g = colorValue(min);
			this.b = colorValue(min);
			this.style = createColorStyle(this.r, this.g, this.b);
		}

		function Dot() {
			this.x = Math.random() * canvas.width;
			this.y = Math.random() * canvas.height;
			this.vx = -.5 + Math.random();
			this.vy = -.5 + Math.random();
			this.radius = Math.random() * 2;
			this.color = new Color();
		}
		Dot.prototype = {
			draw: function() {
				ctx.beginPath();
				ctx.fillStyle = this.color.style;
				ctx.arc(this.x, this.y, this.radius, 0, Math.PI, false);
				ctx.fill();
			}
		};

		function createDots() {
			for (i = 0; i < dots.nb; i++) {
				dots.array.push(new Dot());
			}
		}

		function moveDots() {
			for (i = 0; i < dots.nb; i++) {
				var dot = dots.array[i];
				if (dot.y < 0 || dot.y > canvas.height) {
					dot.vx = dot.vx;
					dot.vy = -dot.vy;
				} else if (dot.x < 0 || dot.x > canvas.width) {
					dot.vx = -dot.vx;
					dot.vy = dot.vy;
				}
				dot.x += dot.vx;
				dot.y += dot.vy;
			}
		}

		function connectDots() {
			for (i = 0; i < dots.nb; i++) {
				for (j = 0; j < dots.nb; j++) {
					i_dot = dots.array[i];
					j_dot = dots.array[j];
					if ((i_dot.x - j_dot.x) < dots.distance && (i_dot.y - j_dot.y) < dots.distance && (i_dot.x - j_dot.x) > -dots.distance && (i_dot.y - j_dot.y) > -dots.distance) {
						if ((i_dot.x - mousePosition.x) < dots.d_radius && (i_dot.y - mousePosition.y) < dots.d_radius && (i_dot.x - mousePosition.x) > -dots.d_radius && (i_dot.y - mousePosition.y) > -dots.d_radius) {
							ctx.beginPath();
							ctx.strokeStyle = averageColorStyles(i_dot, j_dot);
							ctx.moveTo(i_dot.x, i_dot.y);
							ctx.lineTo(j_dot.x, j_dot.y);
							ctx.stroke();
							ctx.closePath();
						}
					}
				}
			}
		}

		function drawDots() {
			for (i = 0; i < dots.nb; i++) {
				var dot = dots.array[i];
				dot.draw();
			}
		}

		function animateDots() {
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			moveDots();
			connectDots();
			drawDots();
			requestAnimationFrame(animateDots);
		}
		$('canvas').on('mousemove', function(e) {
			mousePosition.x = e.pageX;
			mousePosition.y = e.pageY;
		});
		$('canvas').on('mouseleave', function(e) {
			mousePosition.x = canvas.width / 2;
			mousePosition.y = canvas.height / 2;
		});
		createDots();
		requestAnimationFrame(animateDots);
		window.onload = function() {}
	});

</script>

</body>

</html>